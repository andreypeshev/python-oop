from project.pokemon import Pokemon


class Trainer:
    def __init__(self, name: str, pokemons=[]):
        self.name = name
        self.pokemons = pokemons

    def add_pokemon(self, pokemon: Pokemon):
        if pokemon not in self.pokemons:
            self.pokemons.append(pokemon)
            return f"Caught {pokemon.pokemon_details()}"
        return "This pokemon is already caught"

    def release_pokemon(self, pokemon_name: str):
        for el in self.pokemons:
            if el.name == pokemon_name:
                self.pokemons.remove(el)
                return f"You have released {pokemon_name}"
            return f"Pokemon is not caught"

    def trainer_data(self):
        poke_descr = []
        for el in self.pokemons:
            poke_descr.append(f"- {el.pokemon_details()}")

        nl = "\n"
        return f"Pokemon Trainer {self.name}\n" \
               f"Pokemon count {len(self.pokemons)}\n" \
               f"{nl.join(poke_descr)}"

